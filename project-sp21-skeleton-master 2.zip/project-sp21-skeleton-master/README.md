procedure \
On terminal, run python3 solver.py \
for small, change the input directory to inputs/small \
for medium, change the input directory to inputs/medium \
for large, change the input directory to inputs/large
